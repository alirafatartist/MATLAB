% Simscape Multibody Link
% Version 24.1 (R2024a) 19-Nov-2023

%   Copyright 2007-2023 The MathWorks, Inc.
